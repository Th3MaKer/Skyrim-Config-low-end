Copy the Skyrim.ini and SkyrimPrefs.ini in to:
C:\Users\noah\Documents\My Games\Skyrim\ 
it going to ask u replace it or not hit yes and u done 


works for intel hd graphics,amd,nivida that cant run skyrim 
Skyrim SE coming soon on github
